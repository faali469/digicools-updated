"use client";

import { ShoppingBag, Check } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/lib/store/cart";
import type { DbProduct } from "@/lib/types/database";

export function AddToCartButton({ product }: { product: DbProduct }) {
  const addItem = useCartStore((s) => s.addItem);
  const [added, setAdded] = useState(false);

  return (
    <Button
      size="lg"
      className="mt-4 w-full"
      onClick={() => {
        addItem({
          productId: product.id,
          slug: product.slug,
          title: product.title,
          coverImageUrl: product.cover_image_url,
          priceCents: product.price_cents,
          licenseType: product.license_type,
        });
        setAdded(true);
        setTimeout(() => setAdded(false), 1500);
      }}
    >
      {added ? <Check className="h-4 w-4" /> : <ShoppingBag className="h-4 w-4" />}
      {added ? "Added to cart" : "Add to cart"}
    </Button>
  );
}
