"use client";

import Image from "next/image";
import Link from "next/link";
import { Star, ShoppingBag } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatCents } from "@/lib/types/database";
import { useCartStore } from "@/lib/store/cart";
import type { DbProduct } from "@/lib/types/database";

export function ProductCard({ product }: { product: DbProduct }) {
  const addItem = useCartStore((s) => s.addItem);

  return (
    <Card className="group overflow-hidden transition-transform hover:-translate-y-1">
      <Link href={`/products/${product.slug}`}>
        <div className="relative aspect-[4/3] overflow-hidden bg-ink-700">
          {product.cover_image_url ? (
            <Image
              src={product.cover_image_url}
              alt={product.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-mist-400 text-xs">
              No preview
            </div>
          )}
          {product.is_featured && (
            <Badge variant="gold" className="absolute left-3 top-3">Featured</Badge>
          )}
        </div>
      </Link>
      <div className="p-4">
        <Link href={`/products/${product.slug}`}>
          <h3 className="line-clamp-1 font-medium text-mist-50 hover:text-indigo-400">
            {product.title}
          </h3>
        </Link>
        <p className="mt-1 line-clamp-2 text-sm text-mist-400">{product.short_description}</p>

        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-1 text-xs text-mist-400">
            <Star className="h-3.5 w-3.5 fill-gold-400 text-gold-400" />
            {product.rating_average.toFixed(1)}
            <span>({product.rating_count})</span>
          </div>
          <span className="font-display text-base text-mist-50">
            {formatCents(product.price_cents, product.currency)}
          </span>
        </div>

        <Button
          size="sm"
          variant="outline"
          className="mt-3 w-full"
          onClick={() =>
            addItem({
              productId: product.id,
              slug: product.slug,
              title: product.title,
              coverImageUrl: product.cover_image_url,
              priceCents: product.price_cents,
              licenseType: product.license_type,
            })
          }
        >
          <ShoppingBag className="h-4 w-4" /> Add to cart
        </Button>
      </div>
    </Card>
  );
}
