"use client";

import Link from "next/link";
import Image from "next/image";
import { X, Trash2 } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useCartStore } from "@/lib/store/cart";
import { formatCents } from "@/lib/types/database";
import { Button } from "@/components/ui/button";

export function CartDrawer() {
  const { isOpen, setOpen, lines, removeItem, subtotalCents } = useCartStore();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 z-50 bg-black/60"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
          />
          <motion.aside
            className="fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col glass-strong"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 260 }}
          >
            <div className="flex items-center justify-between border-b border-white/[0.06] p-5">
              <h2 className="font-display text-lg">Your cart</h2>
              <button onClick={() => setOpen(false)} aria-label="Close cart">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5">
              {lines.length === 0 ? (
                <p className="mt-10 text-center text-sm text-mist-400">
                  Nothing here yet — browse the marketplace to find your next tool.
                </p>
              ) : (
                <ul className="space-y-4">
                  {lines.map((l) => (
                    <li key={`${l.productId}-${l.licenseType}`} className="flex gap-3">
                      <div className="relative h-16 w-20 shrink-0 overflow-hidden rounded-lg bg-ink-700">
                        {l.coverImageUrl && (
                          <Image src={l.coverImageUrl} alt={l.title} fill className="object-cover" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{l.title}</p>
                        <p className="text-xs text-mist-400 capitalize">{l.licenseType} license</p>
                        <p className="text-sm text-gold-300">{formatCents(l.priceCents)}</p>
                      </div>
                      <button
                        onClick={() => removeItem(l.productId, l.licenseType)}
                        className="text-mist-400 hover:text-red-400"
                        aria-label={`Remove ${l.title}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {lines.length > 0 && (
              <div className="border-t border-white/[0.06] p-5">
                <div className="mb-4 flex items-center justify-between text-sm">
                  <span className="text-mist-400">Subtotal</span>
                  <span className="font-semibold">{formatCents(subtotalCents())}</span>
                </div>
                <Link href="/checkout" onClick={() => setOpen(false)}>
                  <Button className="w-full" size="lg">Checkout</Button>
                </Link>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
