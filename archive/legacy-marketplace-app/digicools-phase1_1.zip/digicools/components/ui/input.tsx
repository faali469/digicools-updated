import * as React from "react";
import { cn } from "@/lib/utils";

const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type, ...props }, ref) => (
    <input
      type={type}
      ref={ref}
      className={cn(
        "flex h-11 w-full rounded-xl border border-ink-500 bg-ink-800 px-4 text-sm text-mist-50 placeholder:text-mist-400 focus-visible:border-indigo-400",
        className
      )}
      {...props}
    />
  )
);
Input.displayName = "Input";

export { Input };
