"use client";

import Link from "next/link";
import { Search, ShoppingBag, Sparkles } from "lucide-react";
import { SignedIn, SignedOut, UserButton } from "@clerk/nextjs";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/lib/store/cart";

export function Navbar() {
  const lines = useCartStore((s) => s.lines);
  const setOpen = useCartStore((s) => s.setOpen);

  return (
    <header className="sticky top-0 z-40 w-full glass">
      <div className="container flex h-16 items-center justify-between gap-6">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <Sparkles className="h-5 w-5 text-gold-400" />
          <span className="font-display text-lg font-semibold tracking-tight">DIGICOOLS</span>
        </Link>

        <div className="hidden md:flex flex-1 max-w-md items-center gap-2 rounded-xl border border-ink-500 bg-ink-800 px-4 h-10">
          <Search className="h-4 w-4 text-mist-400" />
          <input
            placeholder="Search templates, ebooks, prompts…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-mist-400"
          />
        </div>

        <nav className="hidden lg:flex items-center gap-6 text-sm text-mist-200">
          <Link href="/products" className="hover:text-mist-50">Marketplace</Link>
          <Link href="/dashboard/seller" className="hover:text-mist-50">Sell</Link>
          <Link href="/pricing" className="hover:text-mist-50">Pricing</Link>
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setOpen(true)}
            className="relative flex h-10 w-10 items-center justify-center rounded-xl hover:bg-ink-700"
            aria-label="Open cart"
          >
            <ShoppingBag className="h-5 w-5" />
            {lines.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-gold-400 px-1 text-[10px] font-bold text-ink-950">
                {lines.length}
              </span>
            )}
          </button>

          <SignedOut>
            <Link href="/sign-in"><Button size="sm" variant="outline">Log in</Button></Link>
            <Link href="/sign-up"><Button size="sm">Sign up</Button></Link>
          </SignedOut>
          <SignedIn>
            <UserButton afterSignOutUrl="/" />
          </SignedIn>
        </div>
      </div>
    </header>
  );
}
