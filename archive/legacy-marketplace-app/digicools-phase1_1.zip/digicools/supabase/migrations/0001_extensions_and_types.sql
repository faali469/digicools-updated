-- =========================================================
-- DIGICOOLS — Migration 0001: Extensions & Types
-- Run this FIRST in the Supabase SQL Editor.
-- =========================================================

create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ---------- ENUM TYPES ----------
create type user_role as enum ('buyer', 'seller', 'admin');
create type product_status as enum ('draft', 'pending_review', 'published', 'rejected', 'archived');
create type license_type as enum ('personal', 'commercial', 'extended');
create type order_status as enum ('pending', 'paid', 'failed', 'refunded', 'cancelled');
create type payout_status as enum ('pending', 'processing', 'paid', 'failed');
