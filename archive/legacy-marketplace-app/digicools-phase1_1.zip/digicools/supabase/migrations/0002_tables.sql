-- =========================================================
-- DIGICOOLS — Migration 0002: Tables
-- Run this SECOND, after 0001_extensions_and_types.sql.
-- Identity note: real auth (email/password, login sessions) lives in Clerk,
-- not in this database. This `users` table is a mirror of Clerk users,
-- kept in sync automatically by a webhook (app/api/webhooks/clerk/route.ts).
-- =========================================================

-- ---------- USERS ----------
create table users (
  id uuid primary key default uuid_generate_v4(),
  clerk_id text unique not null,
  email text unique not null,
  full_name text,
  avatar_url text,
  role user_role not null default 'buyer',
  is_seller_verified boolean not null default false,
  stripe_customer_id text,
  stripe_connect_account_id text,
  bio text,
  country text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_users_clerk_id on users(clerk_id);
create index idx_users_role on users(role);

-- ---------- CATEGORIES ----------
create table categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique not null,
  parent_id uuid references categories(id) on delete set null,
  icon text,
  description text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create index idx_categories_parent on categories(parent_id);
create index idx_categories_slug on categories(slug);

-- ---------- TAGS ----------
create table tags (
  id uuid primary key default uuid_generate_v4(),
  name text unique not null,
  slug text unique not null
);

-- ---------- PRODUCTS ----------
create table products (
  id uuid primary key default uuid_generate_v4(),
  seller_id uuid not null references users(id) on delete cascade,
  category_id uuid references categories(id) on delete set null,
  title text not null,
  slug text unique not null,
  short_description text,
  description text,
  cover_image_url text,
  preview_images text[] default '{}',
  preview_file_url text,
  main_file_url text,
  main_file_size_bytes bigint,
  version text not null default '1.0.0',
  status product_status not null default 'draft',
  price_cents int not null default 0 check (price_cents >= 0),
  compare_at_price_cents int check (compare_at_price_cents >= 0),
  currency text not null default 'USD',
  license_type license_type not null default 'personal',
  is_featured boolean not null default false,
  downloads_count bigint not null default 0,
  rating_average numeric(3,2) not null default 0,
  rating_count int not null default 0,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_products_seller on products(seller_id);
create index idx_products_category on products(category_id);
create index idx_products_status on products(status);
create index idx_products_slug on products(slug);
create index idx_products_featured on products(is_featured) where is_featured = true;
create index idx_products_search on products using gin (to_tsvector('english', title || ' ' || coalesce(short_description, '')));

create table product_tags (
  product_id uuid not null references products(id) on delete cascade,
  tag_id uuid not null references tags(id) on delete cascade,
  primary key (product_id, tag_id)
);

create table product_versions (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid not null references products(id) on delete cascade,
  version text not null,
  changelog text,
  file_url text not null,
  created_at timestamptz not null default now()
);
create index idx_product_versions_product on product_versions(product_id);

-- ---------- WISHLIST / COLLECTIONS ----------
create table wishlists (
  user_id uuid not null references users(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table collections (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  name text not null,
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);
create table collection_items (
  collection_id uuid not null references collections(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  primary key (collection_id, product_id)
);

-- ---------- CART ----------
create table cart_items (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  license_type license_type not null default 'personal',
  added_at timestamptz not null default now(),
  unique (user_id, product_id, license_type)
);
create index idx_cart_items_user on cart_items(user_id);

-- ---------- COUPONS ----------
create table coupons (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  seller_id uuid references users(id) on delete cascade, -- null = platform-wide
  percent_off int check (percent_off between 1 and 100),
  amount_off_cents int check (amount_off_cents >= 0),
  max_redemptions int,
  times_redeemed int not null default 0,
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  is_active boolean not null default true
);
create index idx_coupons_code on coupons(code);

-- ---------- ORDERS ----------
create table orders (
  id uuid primary key default uuid_generate_v4(),
  order_number text unique not null default ('DC-' || upper(substr(uuid_generate_v4()::text, 1, 8))),
  buyer_id uuid not null references users(id) on delete restrict,
  status order_status not null default 'pending',
  subtotal_cents int not null default 0,
  discount_cents int not null default 0,
  tax_cents int not null default 0,
  total_cents int not null default 0,
  currency text not null default 'USD',
  coupon_id uuid references coupons(id) on delete set null,
  stripe_payment_intent_id text,
  stripe_checkout_session_id text,
  paypal_order_id text,
  billing_country text,
  invoice_number text,
  created_at timestamptz not null default now(),
  paid_at timestamptz,
  updated_at timestamptz not null default now()
);
create index idx_orders_buyer on orders(buyer_id);
create index idx_orders_status on orders(status);
create index idx_orders_stripe_pi on orders(stripe_payment_intent_id);

create table order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id) on delete restrict,
  seller_id uuid not null references users(id) on delete restrict,
  license_type license_type not null default 'personal',
  unit_price_cents int not null,
  commission_rate numeric(4,3) not null default 0.300, -- platform take, e.g. 30%
  commission_cents int not null default 0,
  seller_earning_cents int not null default 0,
  download_token uuid not null default uuid_generate_v4(),
  download_count int not null default 0,
  created_at timestamptz not null default now()
);
create index idx_order_items_order on order_items(order_id);
create index idx_order_items_seller on order_items(seller_id);
create index idx_order_items_product on order_items(product_id);

-- ---------- REVIEWS ----------
create table reviews (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid not null references products(id) on delete cascade,
  buyer_id uuid not null references users(id) on delete cascade,
  order_item_id uuid references order_items(id) on delete set null,
  rating int not null check (rating between 1 and 5),
  title text,
  body text,
  seller_reply text,
  created_at timestamptz not null default now(),
  unique (product_id, buyer_id)
);
create index idx_reviews_product on reviews(product_id);

-- ---------- REFUNDS / SUPPORT ----------
create table refund_requests (
  id uuid primary key default uuid_generate_v4(),
  order_item_id uuid not null references order_items(id) on delete cascade,
  buyer_id uuid not null references users(id) on delete cascade,
  reason text not null,
  status text not null default 'pending', -- pending | approved | rejected
  admin_note text,
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);

create table support_tickets (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  subject text not null,
  status text not null default 'open', -- open | pending | resolved | closed
  priority text not null default 'normal',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table support_messages (
  id uuid primary key default uuid_generate_v4(),
  ticket_id uuid not null references support_tickets(id) on delete cascade,
  sender_id uuid not null references users(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

-- ---------- PAYOUTS ----------
create table payouts (
  id uuid primary key default uuid_generate_v4(),
  seller_id uuid not null references users(id) on delete cascade,
  amount_cents int not null check (amount_cents > 0),
  status payout_status not null default 'pending',
  stripe_transfer_id text,
  requested_at timestamptz not null default now(),
  paid_at timestamptz
);
create index idx_payouts_seller on payouts(seller_id);

-- ---------- AFFILIATE ----------
create table affiliates (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  ref_code text unique not null,
  commission_rate numeric(4,3) not null default 0.100,
  created_at timestamptz not null default now()
);
create table affiliate_referrals (
  id uuid primary key default uuid_generate_v4(),
  affiliate_id uuid not null references affiliates(id) on delete cascade,
  order_id uuid references orders(id) on delete set null,
  referred_user_id uuid references users(id) on delete set null,
  commission_cents int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- NOTIFICATIONS ----------
create table notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  link text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index idx_notifications_user on notifications(user_id, is_read);

-- ---------- AUDIT LOG ----------
create table audit_logs (
  id uuid primary key default uuid_generate_v4(),
  actor_id uuid references users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb default '{}',
  ip_address text,
  created_at timestamptz not null default now()
);
create index idx_audit_logs_entity on audit_logs(entity_type, entity_id);
create index idx_audit_logs_actor on audit_logs(actor_id);
