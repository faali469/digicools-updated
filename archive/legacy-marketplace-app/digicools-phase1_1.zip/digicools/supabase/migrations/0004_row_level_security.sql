-- =========================================================
-- DIGICOOLS — Migration 0004: Row Level Security
-- Run this FOURTH, after 0003_functions_and_triggers.sql.
--
-- Identity note: the app authenticates users with Clerk, not Supabase Auth.
-- Supabase is configured as a "Third Party Auth" project trusting Clerk's
-- JWTs (Project Settings -> Authentication -> Third Party Auth -> Clerk).
-- Every policy below reads the Clerk user id out of that JWT via
-- `auth.jwt() ->> 'sub'` and matches it against `users.clerk_id`.
--
-- The app's server-side "admin" client (service role key) bypasses RLS
-- entirely and is only used inside trusted server code: Stripe/Clerk
-- webhooks and API routes that have already checked who's calling.
-- =========================================================

alter table users enable row level security;
alter table products enable row level security;
alter table cart_items enable row level security;
alter table wishlists enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table reviews enable row level security;
alter table refund_requests enable row level security;
alter table support_tickets enable row level security;
alter table support_messages enable row level security;
alter table notifications enable row level security;
alter table payouts enable row level security;

-- users: a signed-in person can read/update only their own row
create policy users_select_self on users
  for select using (clerk_id = auth.jwt() ->> 'sub');
create policy users_update_self on users
  for update using (clerk_id = auth.jwt() ->> 'sub');

-- products: anyone (including anonymous visitors) can read published
-- products; a seller can additionally see/manage their own, whatever the status
create policy products_select_published on products
  for select using (
    status = 'published'
    or seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy products_modify_own on products
  for all using (
    seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- cart: only the owner can see or change their cart
create policy cart_owner_only on cart_items
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- wishlist: only the owner
create policy wishlist_owner_only on wishlists
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- orders: a buyer sees their own orders
create policy orders_owner_only on orders
  for select using (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- order_items: visible to the buyer who bought it, or the seller who sold it
create policy order_items_visible on order_items
  for select using (
    order_id in (
      select id from orders where buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
    )
    or seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- reviews: anyone can read; only the buyer who wrote it can insert/update their own
create policy reviews_select_all on reviews for select using (true);
create policy reviews_owner_write on reviews
  for insert with check (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy reviews_owner_update on reviews
  for update using (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- refund requests / support tickets & messages / notifications: owner only
create policy refunds_owner_only on refund_requests
  for all using (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy tickets_owner_only on support_tickets
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy ticket_messages_owner_only on support_messages
  for all using (
    ticket_id in (
      select id from support_tickets where user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
    )
  );
create policy notifications_owner_only on notifications
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- payouts: a seller can see their own payout history
create policy payouts_owner_only on payouts
  for select using (
    seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
