-- =========================================================
-- DIGICOOLS — Migration 0003: Functions & Triggers
-- Run this THIRD, after 0002_tables.sql.
-- =========================================================

-- Keep updated_at fresh automatically
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_users_updated_at before update on users
  for each row execute function set_updated_at();
create trigger trg_products_updated_at before update on products
  for each row execute function set_updated_at();
create trigger trg_orders_updated_at before update on orders
  for each row execute function set_updated_at();
create trigger trg_support_tickets_updated_at before update on support_tickets
  for each row execute function set_updated_at();

-- Recalculate product rating whenever a review is inserted/updated/deleted
create or replace function recalc_product_rating()
returns trigger as $$
declare
  target_product uuid;
begin
  target_product := coalesce(new.product_id, old.product_id);
  update products p
  set rating_count = sub.cnt,
      rating_average = coalesce(sub.avg_rating, 0)
  from (
    select product_id, count(*) as cnt, avg(rating)::numeric(3,2) as avg_rating
    from reviews where product_id = target_product
    group by product_id
  ) sub
  where p.id = target_product and sub.product_id = target_product;

  if not exists (select 1 from reviews where product_id = target_product) then
    update products set rating_count = 0, rating_average = 0 where id = target_product;
  end if;

  return null;
end;
$$ language plpgsql;

create trigger trg_reviews_recalc
  after insert or update or delete on reviews
  for each row execute function recalc_product_rating();

-- Auto-compute commission + seller earning whenever an order_item is priced
create or replace function compute_order_item_earnings()
returns trigger as $$
begin
  new.commission_cents := round(new.unit_price_cents * new.commission_rate);
  new.seller_earning_cents := new.unit_price_cents - new.commission_cents;
  return new;
end;
$$ language plpgsql;

create trigger trg_order_items_earnings
  before insert or update of unit_price_cents, commission_rate on order_items
  for each row execute function compute_order_item_earnings();

-- Bump product downloads_count when an order_item's download_count increases
create or replace function bump_product_downloads()
returns trigger as $$
begin
  if new.download_count > old.download_count then
    update products set downloads_count = downloads_count + 1 where id = new.product_id;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_order_items_download
  after update of download_count on order_items
  for each row execute function bump_product_downloads();

-- Audit log every insert/update/delete on products
create or replace function audit_products()
returns trigger as $$
begin
  insert into audit_logs (actor_id, action, entity_type, entity_id, metadata)
  values (
    coalesce(new.seller_id, old.seller_id),
    tg_op,
    'product',
    coalesce(new.id, old.id),
    jsonb_build_object('status', coalesce(new.status, old.status))
  );
  return coalesce(new, old);
end;
$$ language plpgsql;

create trigger trg_audit_products
  after insert or update or delete on products
  for each row execute function audit_products();
