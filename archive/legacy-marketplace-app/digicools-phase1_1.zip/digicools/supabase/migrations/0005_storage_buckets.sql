-- =========================================================
-- DIGICOOLS — Migration 0005: Storage Buckets
-- Run this FIFTH (last), after 0004_row_level_security.sql.
--
-- Folder convention: every uploaded file's path starts with the
-- uploader's Clerk user id, e.g. "user_2abc123/cover.png". That's how
-- the policies below know who owns a file, the same way the database
-- policies use `auth.jwt() ->> 'sub'`.
-- =========================================================

-- ---------- BUCKETS ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('product-covers', 'product-covers', true, 5242880, array['image/png','image/jpeg','image/webp']),
  ('product-previews', 'product-previews', true, 15728640, null),
  ('product-files', 'product-files', false, 524288000, null),
  ('avatars', 'avatars', true, 2097152, array['image/png','image/jpeg','image/webp'])
on conflict (id) do nothing;

-- ---------- PUBLIC READ (covers, previews, avatars) ----------
create policy "Public read product-covers"
  on storage.objects for select
  using (bucket_id = 'product-covers');

create policy "Public read product-previews"
  on storage.objects for select
  using (bucket_id = 'product-previews');

create policy "Public read avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

-- ---------- OWNER-ONLY WRITE (covers, previews, avatars) ----------
-- A user may only upload/replace/delete files inside a folder
-- matching their own Clerk id: e.g. user_2abc123/my-cover.png
create policy "Owners manage their product-covers"
  on storage.objects for all
  using (bucket_id = 'product-covers' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'product-covers' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');

create policy "Owners manage their product-previews"
  on storage.objects for all
  using (bucket_id = 'product-previews' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'product-previews' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');

create policy "Owners manage their own avatar"
  on storage.objects for all
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');

-- ---------- PRIVATE PRODUCT FILES ----------
-- No public read policy at all: this bucket is private. A seller can
-- manage (upload/replace/delete) only their own files. Buyers never read
-- this bucket directly — the app's /api/download route uses the
-- service-role key (which bypasses RLS) to verify a paid order and hand
-- back a short-lived signed URL.
create policy "Sellers manage their own product-files"
  on storage.objects for all
  using (bucket_id = 'product-files' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'product-files' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');
