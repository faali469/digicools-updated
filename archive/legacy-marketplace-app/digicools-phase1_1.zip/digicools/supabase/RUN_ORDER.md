# DIGICOOLS — Supabase backend

Run these files **in order**, in the Supabase SQL Editor (Supabase dashboard
→ your project → left sidebar **SQL Editor** → **New query**).

For each file below: open it, select all, copy, paste into a new query in
the SQL Editor, click **Run**, wait for "Success", then move to the next file.

1. `migrations/0001_extensions_and_types.sql`
2. `migrations/0002_tables.sql`
3. `migrations/0003_functions_and_triggers.sql`
4. `migrations/0004_row_level_security.sql`
5. `migrations/0005_storage_buckets.sql`
6. `seed.sql` — optional, adds sample categories + one demo product so the
   site isn't empty while you're testing.

`schema.sql` in this same folder is just all five migrations glued together
into one file, for reading. Don't run both `schema.sql` and the individual
migration files — pick one or the other (running the 5 separate files is
recommended, since if something goes wrong partway you'll know exactly
which step failed).

## After running these

Go to **Project Settings → Authentication → Third Party Auth** and add
Clerk as a provider — this is what makes the Row Level Security policies in
step 4 actually work (they check the logged-in person's identity from the
Clerk token). Details are in the main `README.md` at the repo root, section 2.1.

## Storage buckets

Step 5 creates four storage buckets automatically — you don't need to
create them by hand in the Storage tab:
- `product-covers` — public, product thumbnail images
- `product-previews` — public, extra preview images/screenshots
- `product-files` — **private**, the actual files a buyer pays for
- `avatars` — public, profile pictures

Sellers upload into a folder named after their own account id, e.g.
`product-covers/<their-id>/cover.png`. Buyers never touch `product-files`
directly — downloads go through the app's own download link, which checks
the order was paid before handing over the file.
