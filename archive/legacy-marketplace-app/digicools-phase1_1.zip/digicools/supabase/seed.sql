-- =========================================================
-- DIGICOOLS — Seed data (optional)
-- Run this LAST, after all 5 migrations, if you want sample data
-- to look at while building. Safe to skip in production.
-- =========================================================

insert into categories (name, slug, sort_order) values
  ('AI', 'ai', 1),
  ('Business', 'business', 2),
  ('Templates', 'templates', 3),
  ('Ebooks', 'ebooks', 4),
  ('Courses', 'courses', 5),
  ('Prompts', 'prompts', 6),
  ('Icons', 'icons', 7),
  ('Fonts', 'fonts', 8),
  ('Mockups', 'mockups', 9),
  ('Presentations', 'presentations', 10),
  ('Resume & CV', 'resume-cv', 11),
  ('WordPress', 'wordpress', 12),
  ('Notion', 'notion', 13),
  ('Figma', 'figma', 14)
on conflict (slug) do nothing;

insert into tags (name, slug) values
  ('Minimal', 'minimal'),
  ('Dark Mode', 'dark-mode'),
  ('Editable', 'editable'),
  ('Beginner Friendly', 'beginner-friendly'),
  ('Best Seller', 'best-seller')
on conflict (slug) do nothing;

-- A demo seller. Replace 'demo_seller_clerk_id' with a real Clerk user id
-- (visible in the Clerk dashboard under Users) once you've signed up at
-- least one test account, if you want this row to represent a real login.
insert into users (clerk_id, email, full_name, role, is_seller_verified)
values ('demo_seller_clerk_id', 'seller@digicools.com', 'Demo Seller', 'seller', true)
on conflict (clerk_id) do nothing;

insert into products (
  seller_id, category_id, title, slug, short_description, description,
  cover_image_url, price_cents, status, license_type, is_featured, published_at
)
select
  u.id,
  c.id,
  'Notion Startup OS Template',
  'notion-startup-os-template',
  'A complete Notion workspace for running an early-stage startup.',
  'Track roadmap, hiring, finances, and investor updates in one connected Notion workspace built for founders.',
  null,
  2900,
  'published',
  'commercial',
  true,
  now()
from users u, categories c
where u.clerk_id = 'demo_seller_clerk_id' and c.slug = 'notion'
on conflict (slug) do nothing;
