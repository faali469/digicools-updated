-- =========================================================
-- DIGICOOLS — Complete Database Schema (reference copy)
-- This is the migrations in supabase/migrations/ concatenated into
-- one file, purely for reading/reference or a single-paste run in the
-- Supabase SQL Editor. The migrations/ folder is the source of truth
-- and what `supabase db push` / GitHub Actions actually run.
-- =========================================================


-- =========================================================
-- DIGICOOLS — Migration 0001: Extensions & Types
-- Run this FIRST in the Supabase SQL Editor.
-- =========================================================

create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ---------- ENUM TYPES ----------
create type user_role as enum ('buyer', 'seller', 'admin');
create type product_status as enum ('draft', 'pending_review', 'published', 'rejected', 'archived');
create type license_type as enum ('personal', 'commercial', 'extended');
create type order_status as enum ('pending', 'paid', 'failed', 'refunded', 'cancelled');
create type payout_status as enum ('pending', 'processing', 'paid', 'failed');


-- =========================================================
-- DIGICOOLS — Migration 0002: Tables
-- Run this SECOND, after 0001_extensions_and_types.sql.
-- Identity note: real auth (email/password, login sessions) lives in Clerk,
-- not in this database. This `users` table is a mirror of Clerk users,
-- kept in sync automatically by a webhook (app/api/webhooks/clerk/route.ts).
-- =========================================================

-- ---------- USERS ----------
create table users (
  id uuid primary key default uuid_generate_v4(),
  clerk_id text unique not null,
  email text unique not null,
  full_name text,
  avatar_url text,
  role user_role not null default 'buyer',
  is_seller_verified boolean not null default false,
  stripe_customer_id text,
  stripe_connect_account_id text,
  bio text,
  country text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_users_clerk_id on users(clerk_id);
create index idx_users_role on users(role);

-- ---------- CATEGORIES ----------
create table categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique not null,
  parent_id uuid references categories(id) on delete set null,
  icon text,
  description text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create index idx_categories_parent on categories(parent_id);
create index idx_categories_slug on categories(slug);

-- ---------- TAGS ----------
create table tags (
  id uuid primary key default uuid_generate_v4(),
  name text unique not null,
  slug text unique not null
);

-- ---------- PRODUCTS ----------
create table products (
  id uuid primary key default uuid_generate_v4(),
  seller_id uuid not null references users(id) on delete cascade,
  category_id uuid references categories(id) on delete set null,
  title text not null,
  slug text unique not null,
  short_description text,
  description text,
  cover_image_url text,
  preview_images text[] default '{}',
  preview_file_url text,
  main_file_url text,
  main_file_size_bytes bigint,
  version text not null default '1.0.0',
  status product_status not null default 'draft',
  price_cents int not null default 0 check (price_cents >= 0),
  compare_at_price_cents int check (compare_at_price_cents >= 0),
  currency text not null default 'USD',
  license_type license_type not null default 'personal',
  is_featured boolean not null default false,
  downloads_count bigint not null default 0,
  rating_average numeric(3,2) not null default 0,
  rating_count int not null default 0,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_products_seller on products(seller_id);
create index idx_products_category on products(category_id);
create index idx_products_status on products(status);
create index idx_products_slug on products(slug);
create index idx_products_featured on products(is_featured) where is_featured = true;
create index idx_products_search on products using gin (to_tsvector('english', title || ' ' || coalesce(short_description, '')));

create table product_tags (
  product_id uuid not null references products(id) on delete cascade,
  tag_id uuid not null references tags(id) on delete cascade,
  primary key (product_id, tag_id)
);

create table product_versions (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid not null references products(id) on delete cascade,
  version text not null,
  changelog text,
  file_url text not null,
  created_at timestamptz not null default now()
);
create index idx_product_versions_product on product_versions(product_id);

-- ---------- WISHLIST / COLLECTIONS ----------
create table wishlists (
  user_id uuid not null references users(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table collections (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  name text not null,
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);
create table collection_items (
  collection_id uuid not null references collections(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  primary key (collection_id, product_id)
);

-- ---------- CART ----------
create table cart_items (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  license_type license_type not null default 'personal',
  added_at timestamptz not null default now(),
  unique (user_id, product_id, license_type)
);
create index idx_cart_items_user on cart_items(user_id);

-- ---------- COUPONS ----------
create table coupons (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  seller_id uuid references users(id) on delete cascade, -- null = platform-wide
  percent_off int check (percent_off between 1 and 100),
  amount_off_cents int check (amount_off_cents >= 0),
  max_redemptions int,
  times_redeemed int not null default 0,
  starts_at timestamptz not null default now(),
  expires_at timestamptz,
  is_active boolean not null default true
);
create index idx_coupons_code on coupons(code);

-- ---------- ORDERS ----------
create table orders (
  id uuid primary key default uuid_generate_v4(),
  order_number text unique not null default ('DC-' || upper(substr(uuid_generate_v4()::text, 1, 8))),
  buyer_id uuid not null references users(id) on delete restrict,
  status order_status not null default 'pending',
  subtotal_cents int not null default 0,
  discount_cents int not null default 0,
  tax_cents int not null default 0,
  total_cents int not null default 0,
  currency text not null default 'USD',
  coupon_id uuid references coupons(id) on delete set null,
  stripe_payment_intent_id text,
  stripe_checkout_session_id text,
  paypal_order_id text,
  billing_country text,
  invoice_number text,
  created_at timestamptz not null default now(),
  paid_at timestamptz,
  updated_at timestamptz not null default now()
);
create index idx_orders_buyer on orders(buyer_id);
create index idx_orders_status on orders(status);
create index idx_orders_stripe_pi on orders(stripe_payment_intent_id);

create table order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id) on delete restrict,
  seller_id uuid not null references users(id) on delete restrict,
  license_type license_type not null default 'personal',
  unit_price_cents int not null,
  commission_rate numeric(4,3) not null default 0.300, -- platform take, e.g. 30%
  commission_cents int not null default 0,
  seller_earning_cents int not null default 0,
  download_token uuid not null default uuid_generate_v4(),
  download_count int not null default 0,
  created_at timestamptz not null default now()
);
create index idx_order_items_order on order_items(order_id);
create index idx_order_items_seller on order_items(seller_id);
create index idx_order_items_product on order_items(product_id);

-- ---------- REVIEWS ----------
create table reviews (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid not null references products(id) on delete cascade,
  buyer_id uuid not null references users(id) on delete cascade,
  order_item_id uuid references order_items(id) on delete set null,
  rating int not null check (rating between 1 and 5),
  title text,
  body text,
  seller_reply text,
  created_at timestamptz not null default now(),
  unique (product_id, buyer_id)
);
create index idx_reviews_product on reviews(product_id);

-- ---------- REFUNDS / SUPPORT ----------
create table refund_requests (
  id uuid primary key default uuid_generate_v4(),
  order_item_id uuid not null references order_items(id) on delete cascade,
  buyer_id uuid not null references users(id) on delete cascade,
  reason text not null,
  status text not null default 'pending', -- pending | approved | rejected
  admin_note text,
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);

create table support_tickets (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  subject text not null,
  status text not null default 'open', -- open | pending | resolved | closed
  priority text not null default 'normal',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table support_messages (
  id uuid primary key default uuid_generate_v4(),
  ticket_id uuid not null references support_tickets(id) on delete cascade,
  sender_id uuid not null references users(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

-- ---------- PAYOUTS ----------
create table payouts (
  id uuid primary key default uuid_generate_v4(),
  seller_id uuid not null references users(id) on delete cascade,
  amount_cents int not null check (amount_cents > 0),
  status payout_status not null default 'pending',
  stripe_transfer_id text,
  requested_at timestamptz not null default now(),
  paid_at timestamptz
);
create index idx_payouts_seller on payouts(seller_id);

-- ---------- AFFILIATE ----------
create table affiliates (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  ref_code text unique not null,
  commission_rate numeric(4,3) not null default 0.100,
  created_at timestamptz not null default now()
);
create table affiliate_referrals (
  id uuid primary key default uuid_generate_v4(),
  affiliate_id uuid not null references affiliates(id) on delete cascade,
  order_id uuid references orders(id) on delete set null,
  referred_user_id uuid references users(id) on delete set null,
  commission_cents int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- NOTIFICATIONS ----------
create table notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  link text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index idx_notifications_user on notifications(user_id, is_read);

-- ---------- AUDIT LOG ----------
create table audit_logs (
  id uuid primary key default uuid_generate_v4(),
  actor_id uuid references users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb default '{}',
  ip_address text,
  created_at timestamptz not null default now()
);
create index idx_audit_logs_entity on audit_logs(entity_type, entity_id);
create index idx_audit_logs_actor on audit_logs(actor_id);


-- =========================================================
-- DIGICOOLS — Migration 0003: Functions & Triggers
-- Run this THIRD, after 0002_tables.sql.
-- =========================================================

-- Keep updated_at fresh automatically
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_users_updated_at before update on users
  for each row execute function set_updated_at();
create trigger trg_products_updated_at before update on products
  for each row execute function set_updated_at();
create trigger trg_orders_updated_at before update on orders
  for each row execute function set_updated_at();
create trigger trg_support_tickets_updated_at before update on support_tickets
  for each row execute function set_updated_at();

-- Recalculate product rating whenever a review is inserted/updated/deleted
create or replace function recalc_product_rating()
returns trigger as $$
declare
  target_product uuid;
begin
  target_product := coalesce(new.product_id, old.product_id);
  update products p
  set rating_count = sub.cnt,
      rating_average = coalesce(sub.avg_rating, 0)
  from (
    select product_id, count(*) as cnt, avg(rating)::numeric(3,2) as avg_rating
    from reviews where product_id = target_product
    group by product_id
  ) sub
  where p.id = target_product and sub.product_id = target_product;

  if not exists (select 1 from reviews where product_id = target_product) then
    update products set rating_count = 0, rating_average = 0 where id = target_product;
  end if;

  return null;
end;
$$ language plpgsql;

create trigger trg_reviews_recalc
  after insert or update or delete on reviews
  for each row execute function recalc_product_rating();

-- Auto-compute commission + seller earning whenever an order_item is priced
create or replace function compute_order_item_earnings()
returns trigger as $$
begin
  new.commission_cents := round(new.unit_price_cents * new.commission_rate);
  new.seller_earning_cents := new.unit_price_cents - new.commission_cents;
  return new;
end;
$$ language plpgsql;

create trigger trg_order_items_earnings
  before insert or update of unit_price_cents, commission_rate on order_items
  for each row execute function compute_order_item_earnings();

-- Bump product downloads_count when an order_item's download_count increases
create or replace function bump_product_downloads()
returns trigger as $$
begin
  if new.download_count > old.download_count then
    update products set downloads_count = downloads_count + 1 where id = new.product_id;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_order_items_download
  after update of download_count on order_items
  for each row execute function bump_product_downloads();

-- Audit log every insert/update/delete on products
create or replace function audit_products()
returns trigger as $$
begin
  insert into audit_logs (actor_id, action, entity_type, entity_id, metadata)
  values (
    coalesce(new.seller_id, old.seller_id),
    tg_op,
    'product',
    coalesce(new.id, old.id),
    jsonb_build_object('status', coalesce(new.status, old.status))
  );
  return coalesce(new, old);
end;
$$ language plpgsql;

create trigger trg_audit_products
  after insert or update or delete on products
  for each row execute function audit_products();


-- =========================================================
-- DIGICOOLS — Migration 0004: Row Level Security
-- Run this FOURTH, after 0003_functions_and_triggers.sql.
--
-- Identity note: the app authenticates users with Clerk, not Supabase Auth.
-- Supabase is configured as a "Third Party Auth" project trusting Clerk's
-- JWTs (Project Settings -> Authentication -> Third Party Auth -> Clerk).
-- Every policy below reads the Clerk user id out of that JWT via
-- `auth.jwt() ->> 'sub'` and matches it against `users.clerk_id`.
--
-- The app's server-side "admin" client (service role key) bypasses RLS
-- entirely and is only used inside trusted server code: Stripe/Clerk
-- webhooks and API routes that have already checked who's calling.
-- =========================================================

alter table users enable row level security;
alter table products enable row level security;
alter table cart_items enable row level security;
alter table wishlists enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table reviews enable row level security;
alter table refund_requests enable row level security;
alter table support_tickets enable row level security;
alter table support_messages enable row level security;
alter table notifications enable row level security;
alter table payouts enable row level security;

-- users: a signed-in person can read/update only their own row
create policy users_select_self on users
  for select using (clerk_id = auth.jwt() ->> 'sub');
create policy users_update_self on users
  for update using (clerk_id = auth.jwt() ->> 'sub');

-- products: anyone (including anonymous visitors) can read published
-- products; a seller can additionally see/manage their own, whatever the status
create policy products_select_published on products
  for select using (
    status = 'published'
    or seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy products_modify_own on products
  for all using (
    seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- cart: only the owner can see or change their cart
create policy cart_owner_only on cart_items
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- wishlist: only the owner
create policy wishlist_owner_only on wishlists
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- orders: a buyer sees their own orders
create policy orders_owner_only on orders
  for select using (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- order_items: visible to the buyer who bought it, or the seller who sold it
create policy order_items_visible on order_items
  for select using (
    order_id in (
      select id from orders where buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
    )
    or seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- reviews: anyone can read; only the buyer who wrote it can insert/update their own
create policy reviews_select_all on reviews for select using (true);
create policy reviews_owner_write on reviews
  for insert with check (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy reviews_owner_update on reviews
  for update using (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- refund requests / support tickets & messages / notifications: owner only
create policy refunds_owner_only on refund_requests
  for all using (
    buyer_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy tickets_owner_only on support_tickets
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );
create policy ticket_messages_owner_only on support_messages
  for all using (
    ticket_id in (
      select id from support_tickets where user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
    )
  );
create policy notifications_owner_only on notifications
  for all using (
    user_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );

-- payouts: a seller can see their own payout history
create policy payouts_owner_only on payouts
  for select using (
    seller_id in (select id from users where clerk_id = auth.jwt() ->> 'sub')
  );


-- =========================================================
-- DIGICOOLS — Migration 0005: Storage Buckets
-- Run this FIFTH (last), after 0004_row_level_security.sql.
--
-- Folder convention: every uploaded file's path starts with the
-- uploader's Clerk user id, e.g. "user_2abc123/cover.png". That's how
-- the policies below know who owns a file, the same way the database
-- policies use `auth.jwt() ->> 'sub'`.
-- =========================================================

-- ---------- BUCKETS ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('product-covers', 'product-covers', true, 5242880, array['image/png','image/jpeg','image/webp']),
  ('product-previews', 'product-previews', true, 15728640, null),
  ('product-files', 'product-files', false, 524288000, null),
  ('avatars', 'avatars', true, 2097152, array['image/png','image/jpeg','image/webp'])
on conflict (id) do nothing;

-- ---------- PUBLIC READ (covers, previews, avatars) ----------
create policy "Public read product-covers"
  on storage.objects for select
  using (bucket_id = 'product-covers');

create policy "Public read product-previews"
  on storage.objects for select
  using (bucket_id = 'product-previews');

create policy "Public read avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

-- ---------- OWNER-ONLY WRITE (covers, previews, avatars) ----------
-- A user may only upload/replace/delete files inside a folder
-- matching their own Clerk id: e.g. user_2abc123/my-cover.png
create policy "Owners manage their product-covers"
  on storage.objects for all
  using (bucket_id = 'product-covers' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'product-covers' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');

create policy "Owners manage their product-previews"
  on storage.objects for all
  using (bucket_id = 'product-previews' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'product-previews' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');

create policy "Owners manage their own avatar"
  on storage.objects for all
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');

-- ---------- PRIVATE PRODUCT FILES ----------
-- No public read policy at all: this bucket is private. A seller can
-- manage (upload/replace/delete) only their own files. Buyers never read
-- this bucket directly — the app's /api/download route uses the
-- service-role key (which bypasses RLS) to verify a paid order and hand
-- back a short-lived signed URL.
create policy "Sellers manage their own product-files"
  on storage.objects for all
  using (bucket_id = 'product-files' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub')
  with check (bucket_id = 'product-files' and (storage.foldername(name))[1] = auth.jwt() ->> 'sub');

