import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_APP_URL || "https://digicools.com";
  return {
    rules: [
      { userAgent: "*", allow: "/", disallow: ["/dashboard", "/api", "/checkout", "/cart"] },
    ],
    sitemap: `${base}/sitemap.xml`,
  };
}
