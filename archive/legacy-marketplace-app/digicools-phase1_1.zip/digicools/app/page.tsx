import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { createSupabasePublicClient } from "@/lib/supabase/public";
import { ProductCard } from "@/components/product-card";
import { Button } from "@/components/ui/button";
import type { DbProduct, DbCategory } from "@/lib/types/database";

export const revalidate = 60;

async function getFeaturedProducts(): Promise<DbProduct[]> {
  const supabase = createSupabasePublicClient();
  const { data } = await supabase
    .from("products")
    .select("*")
    .eq("status", "published")
    .order("is_featured", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(8);
  return (data as DbProduct[]) ?? [];
}

async function getCategories(): Promise<DbCategory[]> {
  const supabase = createSupabasePublicClient();
  const { data } = await supabase.from("categories").select("*").order("sort_order");
  return (data as DbCategory[]) ?? [];
}

export default async function HomePage() {
  const [products, categories] = await Promise.all([getFeaturedProducts(), getCategories()]);

  return (
    <>
      <section className="container pt-20 pb-24">
        <div className="max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-indigo-500/30 bg-indigo-500/10 px-3 py-1 text-xs font-medium text-indigo-400">
            AI-matched, instantly downloadable
          </span>
          <h1 className="mt-6 font-display text-5xl md:text-7xl leading-[1.05] text-balance">
            Every tool a builder needs, <em className="italic text-gold-300">found in seconds.</em>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-mist-200">
            DIGICOOLS is the marketplace for templates, ebooks, prompts, and courses —
            with an assistant that reads your brief and hands you the exact file, not a search page.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link href="/products"><Button size="lg">Browse the marketplace</Button></Link>
            <Link href="/dashboard/seller"><Button size="lg" variant="outline">Start selling <ArrowRight className="h-4 w-4" /></Button></Link>
          </div>
        </div>
      </section>

      {categories.length > 0 && (
        <section className="container pb-16">
          <div className="flex gap-3 overflow-x-auto pb-2">
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/products?category=${c.slug}`}
                className="shrink-0 rounded-xl border border-ink-500 px-4 py-2 text-sm text-mist-200 hover:border-indigo-400 hover:text-mist-50"
              >
                {c.name}
              </Link>
            ))}
          </div>
        </section>
      )}

      <section className="container pb-24">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-2xl">Featured this week</h2>
          <Link href="/products" className="text-sm text-indigo-400 hover:underline">View all →</Link>
        </div>
        {products.length === 0 ? (
          <p className="text-mist-400 text-sm">
            No products published yet — once a seller publishes, it shows up here automatically.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}
