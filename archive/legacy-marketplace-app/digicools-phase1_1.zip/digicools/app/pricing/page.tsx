import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const tiers = [
  {
    name: "Standard seller",
    commission: "30%",
    detail: "Platform fee on every sale. No listing fee, no monthly cost.",
  },
  {
    name: "Verified creator",
    commission: "20%",
    detail: "Unlocked after your first 10 sales and an identity check — lower fee, priority placement.",
  },
];

export default function PricingPage() {
  return (
    <div className="container py-16">
      <h1 className="font-display text-4xl mb-3">Simple, transparent pricing</h1>
      <p className="text-mist-400 mb-10 max-w-xl">
        Buyers never pay a platform fee — the price you see is the price you pay.
        Sellers keep the majority of every sale.
      </p>
      <div className="grid gap-6 sm:grid-cols-2 max-w-3xl">
        {tiers.map((t) => (
          <Card key={t.name} className="p-6">
            <h2 className="font-display text-xl">{t.name}</h2>
            <p className="mt-2 font-display text-4xl text-gold-300">{t.commission}</p>
            <p className="mt-1 text-sm text-mist-400">platform commission</p>
            <p className="mt-4 text-sm text-mist-200">{t.detail}</p>
          </Card>
        ))}
      </div>
      <Link href="/dashboard/seller"><Button size="lg" className="mt-10">Start selling</Button></Link>
    </div>
  );
}
