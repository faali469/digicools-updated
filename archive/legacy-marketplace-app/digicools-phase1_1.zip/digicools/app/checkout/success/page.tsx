import Link from "next/link";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default async function CheckoutSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>;
}) {
  const { order } = await searchParams;

  return (
    <div className="container flex min-h-[70vh] flex-col items-center justify-center py-20 text-center">
      <CheckCircle2 className="h-14 w-14 text-indigo-400" />
      <h1 className="mt-6 font-display text-3xl">Payment confirmed</h1>
      <p className="mt-2 max-w-md text-mist-400">
        {order ? `Order ${order} is paid.` : "Your order is paid."} We've emailed your download
        links, and they're also waiting in your dashboard.
      </p>
      <div className="mt-8 flex gap-4">
        <Link href="/dashboard/buyer"><Button size="lg">Go to my orders</Button></Link>
        <Link href="/products"><Button size="lg" variant="outline">Keep browsing</Button></Link>
      </div>
    </div>
  );
}
