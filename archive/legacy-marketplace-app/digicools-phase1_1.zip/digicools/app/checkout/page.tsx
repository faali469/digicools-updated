"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useUser } from "@clerk/nextjs";
import { useCartStore } from "@/lib/store/cart";
import { formatCents } from "@/lib/types/database";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function CheckoutPage() {
  const { lines, subtotalCents } = useCartStore();
  const { isSignedIn } = useUser();
  const router = useRouter();
  const [couponCode, setCouponCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCheckout() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: lines.map((l) => ({
            productId: l.productId,
            licenseType: l.licenseType,
          })),
          couponCode: couponCode || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Checkout failed");
      window.location.href = data.url;
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
      setLoading(false);
    }
  }

  if (lines.length === 0) {
    return (
      <div className="container py-20 text-center">
        <p className="text-mist-400">Your cart is empty.</p>
        <Button className="mt-4" onClick={() => router.push("/products")}>Browse marketplace</Button>
      </div>
    );
  }

  return (
    <div className="container py-12 max-w-xl">
      <h1 className="font-display text-3xl mb-6">Checkout</h1>

      <Card className="p-6 mb-6">
        <ul className="space-y-3 mb-4">
          {lines.map((l) => (
            <li key={`${l.productId}-${l.licenseType}`} className="flex justify-between text-sm">
              <span>{l.title} <span className="text-mist-400 capitalize">({l.licenseType})</span></span>
              <span>{formatCents(l.priceCents)}</span>
            </li>
          ))}
        </ul>
        <div className="flex gap-2 mb-4">
          <Input
            placeholder="Coupon code"
            value={couponCode}
            onChange={(e) => setCouponCode(e.target.value)}
          />
        </div>
        <div className="border-t border-white/[0.06] pt-4 flex justify-between font-semibold">
          <span>Total</span>
          <span>{formatCents(subtotalCents())}</span>
        </div>
      </Card>

      {error && <p className="mb-4 text-sm text-red-400">{error}</p>}

      <Button size="lg" className="w-full" disabled={loading} onClick={handleCheckout}>
        {loading ? "Redirecting to Stripe…" : isSignedIn ? "Pay with Stripe" : "Sign in to pay"}
      </Button>
      <p className="mt-3 text-center text-xs text-mist-400">
        You'll be redirected to Stripe's secure checkout. Files unlock instantly after payment.
      </p>
    </div>
  );
}
