import type { MetadataRoute } from "next";
import { createSupabasePublicClient } from "@/lib/supabase/public";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_APP_URL || "https://digicools.com";
  const supabase = createSupabasePublicClient();

  const [{ data: products }, { data: categories }] = await Promise.all([
    supabase.from("products").select("slug, updated_at").eq("status", "published"),
    supabase.from("categories").select("slug"),
  ]);

  return [
    { url: base, changeFrequency: "daily", priority: 1 },
    { url: `${base}/products`, changeFrequency: "daily", priority: 0.9 },
    ...(categories ?? []).map((c) => ({
      url: `${base}/products?category=${c.slug}`,
      changeFrequency: "daily" as const,
      priority: 0.6,
    })),
    ...(products ?? []).map((p) => ({
      url: `${base}/products/${p.slug}`,
      lastModified: p.updated_at,
      changeFrequency: "weekly" as const,
      priority: 0.7,
    })),
  ];
}
