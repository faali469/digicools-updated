import Link from "next/link";
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { Plus } from "lucide-react";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { formatCents } from "@/lib/types/database";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default async function SellerDashboardPage() {
  const { userId: clerkId } = await auth();
  if (!clerkId) redirect("/sign-in");

  const admin = createSupabaseAdminClient();
  const { data: seller } = await admin.from("users").select("id").eq("clerk_id", clerkId).single();

  const { data: products } = seller
    ? await admin
        .from("products")
        .select("id, title, slug, status, price_cents, downloads_count, rating_average")
        .eq("seller_id", seller.id)
        .order("created_at", { ascending: false })
    : { data: [] };

  const statusVariant = (status: string) =>
    status === "published" ? "default" : status === "rejected" ? "outline" : "gold";

  return (
    <div className="container py-12">
      <div className="mb-8 flex items-center justify-between">
        <h1 className="font-display text-3xl">Your products</h1>
        <Link href="/dashboard/seller/products/new">
          <Button><Plus className="h-4 w-4" /> New product</Button>
        </Link>
      </div>

      {(!products || products.length === 0) && (
        <Card className="p-10 text-center text-mist-400">
          You haven't listed anything yet. Publish your first digital product to start earning.
        </Card>
      )}

      <div className="space-y-3">
        {products?.map((p) => (
          <Card key={p.id} className="flex flex-wrap items-center justify-between gap-3 p-5">
            <div>
              <p className="font-medium">{p.title}</p>
              <p className="text-xs text-mist-400">{p.downloads_count} downloads · ★ {p.rating_average.toFixed(1)}</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant={statusVariant(p.status) as any}>{p.status.replace("_", " ")}</Badge>
              <span className="font-display">{formatCents(p.price_cents)}</span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
