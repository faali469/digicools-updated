"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const CATEGORIES = [
  "ai", "business", "templates", "ebooks", "courses", "prompts",
  "icons", "fonts", "mockups", "presentations", "resume-cv", "wordpress", "notion", "figma",
];

export default function NewProductPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    title: "",
    shortDescription: "",
    description: "",
    categorySlug: "templates",
    price: "29.00",
    licenseType: "personal",
    coverImageUrl: "",
    mainFileUrl: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: form.title,
          shortDescription: form.shortDescription,
          description: form.description,
          categorySlug: form.categorySlug,
          priceCents: Math.round(parseFloat(form.price || "0") * 100),
          licenseType: form.licenseType,
          coverImageUrl: form.coverImageUrl || undefined,
          mainFileUrl: form.mainFileUrl || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not create product");
      router.push("/dashboard/seller");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container max-w-2xl py-12">
      <h1 className="font-display text-3xl mb-8">List a new product</h1>
      <Card className="p-6">
        <form className="space-y-5" onSubmit={handleSubmit}>
          <div>
            <label className="mb-1.5 block text-sm text-mist-200">Title</label>
            <Input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Notion Startup OS Template" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-mist-200">Short description</label>
            <Input value={form.shortDescription} onChange={(e) => setForm({ ...form, shortDescription: e.target.value })} placeholder="One line that sells it" maxLength={200} />
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-mist-200">Full description</label>
            <textarea
              className="min-h-32 w-full rounded-xl border border-ink-500 bg-ink-800 p-4 text-sm placeholder:text-mist-400 focus-visible:border-indigo-400"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="What's included, who it's for, how to use it…"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-sm text-mist-200">Category</label>
              <select
                className="h-11 w-full rounded-xl border border-ink-500 bg-ink-800 px-4 text-sm"
                value={form.categorySlug}
                onChange={(e) => setForm({ ...form, categorySlug: e.target.value })}
              >
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-sm text-mist-200">License</label>
              <select
                className="h-11 w-full rounded-xl border border-ink-500 bg-ink-800 px-4 text-sm"
                value={form.licenseType}
                onChange={(e) => setForm({ ...form, licenseType: e.target.value })}
              >
                <option value="personal">Personal</option>
                <option value="commercial">Commercial</option>
                <option value="extended">Extended</option>
              </select>
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-mist-200">Price (USD)</label>
            <Input required type="number" min="0" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-mist-200">Cover image URL</label>
            <Input value={form.coverImageUrl} onChange={(e) => setForm({ ...form, coverImageUrl: e.target.value })} placeholder="https://…" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm text-mist-200">Product file URL</label>
            <Input value={form.mainFileUrl} onChange={(e) => setForm({ ...form, mainFileUrl: e.target.value })} placeholder="Uploaded via Supabase Storage / R2" />
            <p className="mt-1 text-xs text-mist-400">
              Upload your file to Supabase Storage or R2 first, then paste the resulting URL here.
              A direct upload widget lands in the next iteration.
            </p>
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <Button type="submit" size="lg" className="w-full" disabled={loading}>
            {loading ? "Submitting…" : "Submit for review"}
          </Button>
          <p className="text-center text-xs text-mist-400">
            New listings go to <strong>pending review</strong> before appearing in the marketplace.
          </p>
        </form>
      </Card>
    </div>
  );
}
