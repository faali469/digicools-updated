import Link from "next/link";
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { formatCents } from "@/lib/types/database";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default async function BuyerDashboardPage() {
  const { userId } = await auth();
  if (!userId) redirect("/sign-in");

  const supabase = await createSupabaseServerClient();
  const { data: orders } = await supabase
    .from("orders")
    .select("id, order_number, status, total_cents, currency, created_at")
    .order("created_at", { ascending: false });

  // order_items are fetched with the admin client here purely to resolve
  // download tokens + product titles for display; RLS above already scoped
  // `orders` to this buyer, so we only ever look up items for their own orders.
  const admin = createSupabaseAdminClient();
  const orderIds = (orders ?? []).map((o) => o.id);
  const { data: items } = orderIds.length
    ? await admin
        .from("order_items")
        .select("order_id, download_token, product:products(title)")
        .in("order_id", orderIds)
    : { data: [] };

  return (
    <div className="container py-12">
      <h1 className="font-display text-3xl mb-8">My orders</h1>

      {(!orders || orders.length === 0) && (
        <Card className="p-10 text-center text-mist-400">
          You haven't purchased anything yet. <Link href="/products" className="text-indigo-400 hover:underline">Browse the marketplace →</Link>
        </Card>
      )}

      <div className="space-y-4">
        {orders?.map((order) => {
          const orderItems = items?.filter((i) => i.order_id === order.id) ?? [];
          return (
            <Card key={order.id} className="p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-medium">{order.order_number}</p>
                  <p className="text-xs text-mist-400">{new Date(order.created_at).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={order.status === "paid" ? "default" : "outline"}>{order.status}</Badge>
                  <span className="font-display">{formatCents(order.total_cents, order.currency)}</span>
                </div>
              </div>
              {order.status === "paid" && orderItems.length > 0 && (
                <ul className="mt-4 space-y-1 border-t border-white/[0.06] pt-3">
                  {orderItems.map((item: any) => (
                    <li key={item.download_token} className="flex items-center justify-between text-sm">
                      <span>{item.product?.title}</span>
                      <Link
                        href={`/api/download/${item.download_token}`}
                        className="text-indigo-400 hover:underline"
                      >
                        Download
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
