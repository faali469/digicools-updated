import { SignUp } from "@clerk/nextjs";

export default function SignUpPage() {
  return (
    <div className="flex min-h-[80vh] items-center justify-center py-12">
      <SignUp
        appearance={{
          variables: {
            colorPrimary: "#5B5FEF",
            colorBackground: "#11151F",
            colorText: "#F5F6F8",
            colorInputBackground: "#171C29",
            borderRadius: "1rem",
          },
        }}
      />
    </div>
  );
}
