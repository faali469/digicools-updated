"use client";

import Image from "next/image";
import Link from "next/link";
import { Trash2 } from "lucide-react";
import { useCartStore } from "@/lib/store/cart";
import { formatCents } from "@/lib/types/database";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function CartPage() {
  const { lines, removeItem, subtotalCents } = useCartStore();

  if (lines.length === 0) {
    return (
      <div className="container py-20 text-center">
        <h1 className="font-display text-3xl mb-3">Your cart is empty</h1>
        <p className="text-mist-400 mb-6">Find something worth building with.</p>
        <Link href="/products"><Button>Browse marketplace</Button></Link>
      </div>
    );
  }

  return (
    <div className="container py-12 grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-10">
      <div>
        <h1 className="font-display text-3xl mb-6">Your cart</h1>
        <div className="space-y-4">
          {lines.map((l) => (
            <Card key={`${l.productId}-${l.licenseType}`} className="flex items-center gap-4 p-4">
              <div className="relative h-20 w-28 shrink-0 overflow-hidden rounded-lg bg-ink-700">
                {l.coverImageUrl && <Image src={l.coverImageUrl} alt={l.title} fill className="object-cover" />}
              </div>
              <div className="flex-1">
                <p className="font-medium">{l.title}</p>
                <p className="text-sm text-mist-400 capitalize">{l.licenseType} license</p>
              </div>
              <span className="font-display text-lg">{formatCents(l.priceCents)}</span>
              <button
                onClick={() => removeItem(l.productId, l.licenseType)}
                className="ml-2 text-mist-400 hover:text-red-400"
                aria-label={`Remove ${l.title}`}
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </Card>
          ))}
        </div>
      </div>

      <Card className="h-fit p-6">
        <h2 className="font-display text-xl mb-4">Order summary</h2>
        <div className="flex justify-between text-sm mb-2">
          <span className="text-mist-400">Subtotal</span>
          <span>{formatCents(subtotalCents())}</span>
        </div>
        <div className="flex justify-between text-sm mb-4">
          <span className="text-mist-400">Tax</span>
          <span>Calculated at checkout</span>
        </div>
        <div className="border-t border-white/[0.06] pt-4 flex justify-between font-semibold mb-6">
          <span>Total</span>
          <span>{formatCents(subtotalCents())}</span>
        </div>
        <Link href="/checkout"><Button size="lg" className="w-full">Proceed to checkout</Button></Link>
      </Card>
    </div>
  );
}
