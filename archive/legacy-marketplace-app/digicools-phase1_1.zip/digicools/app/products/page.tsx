import { createSupabasePublicClient } from "@/lib/supabase/public";
import { ProductCard } from "@/components/product-card";
import type { DbProduct } from "@/lib/types/database";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Marketplace",
  description: "Browse templates, ebooks, courses, prompts, and AI-ready digital products.",
};

export const revalidate = 30;

async function getProducts(params: { category?: string; q?: string }) {
  const supabase = createSupabasePublicClient();
  let query = supabase
    .from("products")
    .select("*, category:categories(id, name, slug)")
    .eq("status", "published")
    .order("created_at", { ascending: false });

  if (params.category) {
    const { data: cat } = await supabase
      .from("categories")
      .select("id")
      .eq("slug", params.category)
      .single();
    if (cat) query = query.eq("category_id", cat.id);
  }
  if (params.q) {
    query = query.textSearch("title", params.q, { type: "websearch" });
  }

  const { data } = await query.limit(60);
  return (data as DbProduct[]) ?? [];
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; q?: string }>;
}) {
  const params = await searchParams;
  const products = await getProducts(params);

  return (
    <div className="container py-12">
      <h1 className="font-display text-3xl mb-2">Marketplace</h1>
      <p className="text-mist-400 mb-8">
        {products.length} product{products.length === 1 ? "" : "s"}
        {params.category ? ` in ${params.category}` : ""}
      </p>

      {products.length === 0 ? (
        <div className="rounded-2xl glass p-10 text-center text-mist-400">
          No products match this filter yet. Try a different category or check back soon.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
