import Image from "next/image";
import { notFound } from "next/navigation";
import { Star, ShieldCheck, Download } from "lucide-react";
import { createSupabasePublicClient } from "@/lib/supabase/public";
import { formatCents } from "@/lib/types/database";
import type { DbProduct } from "@/lib/types/database";
import { AddToCartButton } from "@/components/add-to-cart-button";
import type { Metadata } from "next";

async function getProduct(slug: string): Promise<DbProduct | null> {
  const supabase = createSupabasePublicClient();
  const { data } = await supabase
    .from("products")
    .select("*, seller:users(id, full_name, avatar_url, is_seller_verified), category:categories(id, name, slug)")
    .eq("slug", slug)
    .eq("status", "published")
    .single();
  return (data as DbProduct) ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) return {};
  return {
    title: product.title,
    description: product.short_description ?? undefined,
    openGraph: {
      title: product.title,
      description: product.short_description ?? undefined,
      images: product.cover_image_url ? [product.cover_image_url] : undefined,
    },
  };
}

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.title,
    description: product.short_description,
    image: product.cover_image_url,
    offers: {
      "@type": "Offer",
      priceCurrency: product.currency,
      price: (product.price_cents / 100).toFixed(2),
      availability: "https://schema.org/InStock",
    },
    aggregateRating: product.rating_count
      ? {
          "@type": "AggregateRating",
          ratingValue: product.rating_average,
          reviewCount: product.rating_count,
        }
      : undefined,
  };

  return (
    <div className="container py-12 grid grid-cols-1 lg:grid-cols-[1.4fr_1fr] gap-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div>
        <div className="relative aspect-video overflow-hidden rounded-2xl bg-ink-700">
          {product.cover_image_url && (
            <Image src={product.cover_image_url} alt={product.title} fill className="object-cover" priority />
          )}
        </div>
        <h1 className="mt-6 font-display text-3xl">{product.title}</h1>
        <div className="mt-2 flex items-center gap-3 text-sm text-mist-400">
          <span className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-gold-400 text-gold-400" />
            {product.rating_average.toFixed(1)} ({product.rating_count} reviews)
          </span>
          <span>·</span>
          <span>{product.downloads_count} downloads</span>
        </div>
        <p className="mt-6 leading-relaxed text-mist-200 whitespace-pre-line">{product.description}</p>
      </div>

      <aside className="h-fit rounded-2xl glass p-6 lg:sticky lg:top-24">
        <p className="font-display text-3xl">{formatCents(product.price_cents, product.currency)}</p>
        <p className="mt-1 text-sm capitalize text-mist-400">{product.license_type} license</p>

        <AddToCartButton product={product} />

        <ul className="mt-6 space-y-2 text-sm text-mist-200">
          <li className="flex items-center gap-2"><Download className="h-4 w-4 text-indigo-400" /> Instant download after payment</li>
          <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-indigo-400" /> Verified seller, secure checkout</li>
        </ul>

        {product.seller && (
          <div className="mt-6 border-t border-white/[0.06] pt-4">
            <p className="text-xs text-mist-400 mb-1">Sold by</p>
            <p className="text-sm font-medium">{product.seller.full_name}</p>
          </div>
        )}
      </aside>
    </div>
  );
}
