import { NextRequest, NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe } from "@/lib/stripe";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { Resend } from "resend";
import Stripe from "stripe";

export const runtime = "nodejs";

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = (await headers()).get("stripe-signature");

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, signature!, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err) {
    console.error("Stripe webhook signature verification failed", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const admin = createSupabaseAdminClient();

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      const orderId = session.metadata?.order_id;
      if (!orderId) break;

      const { data: order } = await admin
        .from("orders")
        .update({
          status: "paid",
          paid_at: new Date().toISOString(),
          stripe_payment_intent_id:
            typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id,
        })
        .eq("id", orderId)
        .select("id, order_number, buyer_id, total_cents, currency")
        .single();

      if (!order) break;

      if (order.buyer_id) {
        const { data: buyer } = await admin.from("users").select("email, full_name").eq("id", order.buyer_id).single();
        const { data: items } = await admin
          .from("order_items")
          .select("download_token, product:products(title, main_file_url)")
          .eq("order_id", order.id);

        if (buyer && resend && items) {
          const links = items
            .map((i: any) => `${i.product?.title}: ${process.env.NEXT_PUBLIC_APP_URL}/api/download/${i.download_token}`)
            .join("\n");
          await resend.emails.send({
            from: process.env.RESEND_FROM_EMAIL ?? "orders@digicools.com",
            to: buyer.email,
            subject: `Your DIGICOOLS order ${order.order_number} is ready`,
            text: `Thanks for your purchase!\n\nDownload your files:\n${links}\n\nOrder total: ${(order.total_cents / 100).toFixed(2)} ${order.currency}`,
          });
        }

        await admin.from("notifications").insert({
          user_id: order.buyer_id,
          type: "order_paid",
          title: "Order confirmed",
          body: `Order ${order.order_number} is ready to download.`,
          link: `/dashboard/buyer/orders/${order.id}`,
        });
      }
      break;
    }

    case "checkout.session.expired": {
      const session = event.data.object as Stripe.Checkout.Session;
      const orderId = session.metadata?.order_id;
      if (orderId) {
        await admin.from("orders").update({ status: "cancelled" }).eq("id", orderId);
      }
      break;
    }

    case "charge.refunded": {
      const charge = event.data.object as Stripe.Charge;
      const paymentIntentId = typeof charge.payment_intent === "string" ? charge.payment_intent : charge.payment_intent?.id;
      if (paymentIntentId) {
        await admin.from("orders").update({ status: "refunded" }).eq("stripe_payment_intent_id", paymentIntentId);
      }
      break;
    }

    default:
      break;
  }

  return NextResponse.json({ received: true });
}
