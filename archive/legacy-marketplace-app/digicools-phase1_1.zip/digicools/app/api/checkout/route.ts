import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { stripe } from "@/lib/stripe";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const bodySchema = z.object({
  items: z
    .array(
      z.object({
        productId: z.string().uuid(),
        licenseType: z.enum(["personal", "commercial", "extended"]),
      })
    )
    .min(1),
  couponCode: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const { userId: clerkId } = await auth();
  if (!clerkId) {
    return NextResponse.json({ error: "You must be signed in to checkout." }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid checkout payload." }, { status: 400 });
  }
  const { items, couponCode } = parsed.data;

  const admin = createSupabaseAdminClient();

  const { data: buyer, error: buyerError } = await admin
    .from("users")
    .select("id, email, stripe_customer_id")
    .eq("clerk_id", clerkId)
    .single();
  if (buyerError || !buyer) {
    return NextResponse.json({ error: "Buyer account not found. Please refresh and sign in again." }, { status: 404 });
  }

  const productIds = items.map((i) => i.productId);
  const { data: products, error: productsError } = await admin
    .from("products")
    .select("id, title, price_cents, currency, status, seller_id, cover_image_url")
    .in("id", productIds)
    .eq("status", "published");

  if (productsError || !products || products.length !== productIds.length) {
    return NextResponse.json({ error: "One or more items are no longer available." }, { status: 409 });
  }

  let discountCents = 0;
  let coupon: { id: string; percent_off: number | null; amount_off_cents: number | null } | null = null;

  const subtotalCents = products.reduce((sum, p) => sum + p.price_cents, 0);

  if (couponCode) {
    const { data: c } = await admin
      .from("coupons")
      .select("id, percent_off, amount_off_cents, is_active, expires_at, max_redemptions, times_redeemed")
      .eq("code", couponCode.toUpperCase())
      .single();

    if (c && c.is_active && (!c.expires_at || new Date(c.expires_at) > new Date())
        && (!c.max_redemptions || c.times_redeemed < c.max_redemptions)) {
      coupon = c;
      discountCents = c.percent_off
        ? Math.round((subtotalCents * c.percent_off) / 100)
        : c.amount_off_cents ?? 0;
    }
  }

  const totalCents = Math.max(subtotalCents - discountCents, 0);

  const { data: order, error: orderError } = await admin
    .from("orders")
    .insert({
      buyer_id: buyer.id,
      status: "pending",
      subtotal_cents: subtotalCents,
      discount_cents: discountCents,
      total_cents: totalCents,
      coupon_id: coupon?.id ?? null,
    })
    .select("id, order_number")
    .single();

  if (orderError || !order) {
    return NextResponse.json({ error: "Could not create order." }, { status: 500 });
  }

  const orderItemsPayload = items.map((item) => {
    const product = products.find((p) => p.id === item.productId)!;
    return {
      order_id: order.id,
      product_id: product.id,
      seller_id: product.seller_id,
      license_type: item.licenseType,
      unit_price_cents: product.price_cents,
    };
  });
  const { error: itemsError } = await admin.from("order_items").insert(orderItemsPayload);
  if (itemsError) {
    return NextResponse.json({ error: "Could not attach items to order." }, { status: 500 });
  }

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_email: buyer.stripe_customer_id ? undefined : buyer.email,
    customer: buyer.stripe_customer_id ?? undefined,
    line_items: products.map((p) => ({
      price_data: {
        currency: p.currency.toLowerCase(),
        product_data: {
          name: p.title,
          images: p.cover_image_url ? [p.cover_image_url] : undefined,
        },
        unit_amount: p.price_cents,
      },
      quantity: 1,
    })),
    discounts: coupon
      ? undefined // Stripe-side coupons can be wired in Phase 2; discount is already reflected in `orders.discount_cents`.
      : undefined,
    metadata: { order_id: order.id, order_number: order.order_number },
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/checkout/success?order=${order.order_number}`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/checkout`,
  });

  await admin.from("orders").update({ stripe_checkout_session_id: session.id }).eq("id", order.id);

  return NextResponse.json({ url: session.url });
}
