import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { z } from "zod";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

const createSchema = z.object({
  title: z.string().min(3).max(140),
  shortDescription: z.string().max(200).optional(),
  description: z.string().max(20000).optional(),
  categorySlug: z.string().optional(),
  priceCents: z.number().int().min(0),
  licenseType: z.enum(["personal", "commercial", "extended"]).default("personal"),
  coverImageUrl: z.string().url().optional(),
  mainFileUrl: z.string().url().optional(),
});

function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export async function POST(req: NextRequest) {
  const { userId: clerkId } = await auth();
  if (!clerkId) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const parsed = createSchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }
  const input = parsed.data;

  const admin = createSupabaseAdminClient();
  const { data: seller } = await admin.from("users").select("id, role").eq("clerk_id", clerkId).single();
  if (!seller) return NextResponse.json({ error: "Account not found." }, { status: 404 });

  if (seller.role === "buyer") {
    await admin.from("users").update({ role: "seller" }).eq("id", seller.id);
  }

  let categoryId: string | null = null;
  if (input.categorySlug) {
    const { data: cat } = await admin.from("categories").select("id").eq("slug", input.categorySlug).single();
    categoryId = cat?.id ?? null;
  }

  const baseSlug = slugify(input.title);
  const slug = `${baseSlug}-${Math.random().toString(36).slice(2, 7)}`;

  const { data: product, error } = await admin
    .from("products")
    .insert({
      seller_id: seller.id,
      category_id: categoryId,
      title: input.title,
      slug,
      short_description: input.shortDescription,
      description: input.description,
      price_cents: input.priceCents,
      license_type: input.licenseType,
      cover_image_url: input.coverImageUrl,
      main_file_url: input.mainFileUrl,
      status: "pending_review",
    })
    .select("id, slug")
    .single();

  if (error || !product) {
    return NextResponse.json({ error: "Could not create product." }, { status: 500 });
  }

  return NextResponse.json({ product }, { status: 201 });
}

export async function GET() {
  const { userId: clerkId } = await auth();
  if (!clerkId) return NextResponse.json({ error: "Sign in required." }, { status: 401 });

  const admin = createSupabaseAdminClient();
  const { data: seller } = await admin.from("users").select("id").eq("clerk_id", clerkId).single();
  if (!seller) return NextResponse.json({ products: [] });

  const { data: products } = await admin
    .from("products")
    .select("id, title, slug, status, price_cents, downloads_count, rating_average, created_at")
    .eq("seller_id", seller.id)
    .order("created_at", { ascending: false });

  return NextResponse.json({ products: products ?? [] });
}
