import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

export async function GET(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const { userId: clerkId } = await auth();
  if (!clerkId) {
    return NextResponse.redirect(new URL("/sign-in", req.url));
  }

  const admin = createSupabaseAdminClient();

  const { data: item } = await admin
    .from("order_items")
    .select("id, download_count, product:products(main_file_url, title), order:orders(status, buyer_id)")
    .eq("download_token", token)
    .single();

  if (!item || !item.order) {
    return NextResponse.json({ error: "Invalid or expired download link." }, { status: 404 });
  }
  if ((item.order as any).status !== "paid") {
    return NextResponse.json({ error: "This order has not been paid yet." }, { status: 403 });
  }

  const { data: buyer } = await admin.from("users").select("id").eq("clerk_id", clerkId).single();
  if (!buyer || buyer.id !== (item.order as any).buyer_id) {
    return NextResponse.json({ error: "You do not have access to this file." }, { status: 403 });
  }

  const fileRef = (item.product as any)?.main_file_url;
  if (!fileRef) {
    return NextResponse.json({ error: "File not available yet." }, { status: 404 });
  }

  await admin.from("order_items").update({ download_count: item.download_count + 1 }).eq("id", item.id);

  // `main_file_url` stores a path inside the private "product-files" bucket
  // (e.g. "user_2abc123/my-template.zip"), not a public URL — this bucket
  // has no public read policy, so we must mint a short-lived signed URL.
  // If a full http(s) URL was stored instead (e.g. an external CDN), just
  // redirect to it directly.
  if (/^https?:\/\//.test(fileRef)) {
    return NextResponse.redirect(fileRef);
  }

  const { data: signed, error: signError } = await admin.storage
    .from("product-files")
    .createSignedUrl(fileRef, 60 * 10); // valid for 10 minutes

  if (signError || !signed) {
    return NextResponse.json({ error: "Could not generate a download link." }, { status: 500 });
  }

  return NextResponse.redirect(signed.signedUrl);
}
