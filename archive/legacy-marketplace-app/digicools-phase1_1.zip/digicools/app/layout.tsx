import type { Metadata } from "next";
import { Fraunces, Inter, IBM_Plex_Mono } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import "./globals.css";
import { Navbar } from "@/components/navbar";
import { CartDrawer } from "@/components/cart-drawer";

const display = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "600"],
  style: ["normal", "italic"],
});
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
const mono = IBM_Plex_Mono({ subsets: ["latin"], variable: "--font-mono", weight: ["400", "500"] });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "https://digicools.com"),
  title: {
    default: "DIGICOOLS — The World's Smartest AI Digital Marketplace",
    template: "%s · DIGICOOLS",
  },
  description:
    "Buy and sell templates, ebooks, courses, prompts, and AI-ready assets on DIGICOOLS — instant download, verified sellers, secure checkout.",
  openGraph: {
    type: "website",
    siteName: "DIGICOOLS",
    title: "DIGICOOLS — The World's Smartest AI Digital Marketplace",
    description: "Buy and sell digital products with instant download and verified sellers.",
  },
  robots: { index: true, follow: true },
  manifest: "/manifest.json",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
        <body className="min-h-screen bg-ink-900 font-body text-mist-50 antialiased">
          <Navbar />
          <main>{children}</main>
          <CartDrawer />
        </body>
      </html>
    </ClerkProvider>
  );
}
