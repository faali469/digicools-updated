import { SignIn } from "@clerk/nextjs";

export default function SignInPage() {
  return (
    <div className="flex min-h-[80vh] items-center justify-center py-12">
      <SignIn
        appearance={{
          variables: {
            colorPrimary: "#5B5FEF",
            colorBackground: "#11151F",
            colorText: "#F5F6F8",
            colorInputBackground: "#171C29",
            borderRadius: "1rem",
          },
        }}
      />
    </div>
  );
}
