export type UserRole = "buyer" | "seller" | "admin";
export type ProductStatus = "draft" | "pending_review" | "published" | "rejected" | "archived";
export type LicenseType = "personal" | "commercial" | "extended";
export type OrderStatus = "pending" | "paid" | "failed" | "refunded" | "cancelled";

export interface DbUser {
  id: string;
  clerk_id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  role: UserRole;
  is_seller_verified: boolean;
  stripe_customer_id: string | null;
  stripe_connect_account_id: string | null;
  bio: string | null;
  country: string | null;
  created_at: string;
  updated_at: string;
}

export interface DbCategory {
  id: string;
  name: string;
  slug: string;
  parent_id: string | null;
  icon: string | null;
  description: string | null;
  sort_order: number;
}

export interface DbProduct {
  id: string;
  seller_id: string;
  category_id: string | null;
  title: string;
  slug: string;
  short_description: string | null;
  description: string | null;
  cover_image_url: string | null;
  preview_images: string[];
  price_cents: number;
  compare_at_price_cents: number | null;
  currency: string;
  license_type: LicenseType;
  status: ProductStatus;
  is_featured: boolean;
  downloads_count: number;
  rating_average: number;
  rating_count: number;
  created_at: string;
  updated_at: string;
  seller?: Pick<DbUser, "id" | "full_name" | "avatar_url" | "is_seller_verified">;
  category?: Pick<DbCategory, "id" | "name" | "slug">;
}

export interface DbCartItem {
  id: string;
  user_id: string;
  product_id: string;
  license_type: LicenseType;
  added_at: string;
  product?: DbProduct;
}

export interface DbOrder {
  id: string;
  order_number: string;
  buyer_id: string;
  status: OrderStatus;
  subtotal_cents: number;
  discount_cents: number;
  tax_cents: number;
  total_cents: number;
  currency: string;
  created_at: string;
  paid_at: string | null;
}

export interface DbOrderItem {
  id: string;
  order_id: string;
  product_id: string;
  seller_id: string;
  license_type: LicenseType;
  unit_price_cents: number;
  seller_earning_cents: number;
  download_token: string;
  download_count: number;
}

export function formatCents(cents: number, currency = "USD"): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(cents / 100);
}
