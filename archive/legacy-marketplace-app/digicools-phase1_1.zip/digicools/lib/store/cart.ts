import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { LicenseType } from "@/lib/types/database";

export interface CartLine {
  productId: string;
  slug: string;
  title: string;
  coverImageUrl: string | null;
  priceCents: number;
  licenseType: LicenseType;
}

interface CartState {
  lines: CartLine[];
  isOpen: boolean;
  addItem: (line: CartLine) => void;
  removeItem: (productId: string, licenseType: LicenseType) => void;
  clear: () => void;
  setOpen: (open: boolean) => void;
  subtotalCents: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      isOpen: false,
      addItem: (line) =>
        set((state) => {
          const exists = state.lines.some(
            (l) => l.productId === line.productId && l.licenseType === line.licenseType
          );
          if (exists) return state;
          return { lines: [...state.lines, line], isOpen: true };
        }),
      removeItem: (productId, licenseType) =>
        set((state) => ({
          lines: state.lines.filter(
            (l) => !(l.productId === productId && l.licenseType === licenseType)
          ),
        })),
      clear: () => set({ lines: [] }),
      setOpen: (open) => set({ isOpen: open }),
      subtotalCents: () => get().lines.reduce((sum, l) => sum + l.priceCents, 0),
    }),
    { name: "digicools-cart" }
  )
);
