import "server-only";
import { createClient } from "@supabase/supabase-js";

/**
 * SERVICE ROLE client — bypasses Row Level Security entirely.
 * Only ever import this inside API routes / webhooks that run on the
 * server and have already verified the caller (e.g. Stripe signature,
 * Clerk webhook signature, or an admin-role check). Never expose this
 * client or the service role key to the browser.
 */
export function createSupabaseAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}
