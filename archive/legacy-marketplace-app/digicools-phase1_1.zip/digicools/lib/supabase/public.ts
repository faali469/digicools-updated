import { createClient } from "@supabase/supabase-js";

/**
 * Anonymous client for public reads (published product listings, categories).
 * RLS still applies — the `products_select_published` policy allows anyone
 * to read rows where status = 'published'.
 */
export function createSupabasePublicClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
