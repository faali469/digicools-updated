import { createServerClient } from "@supabase/ssr";
import { auth } from "@clerk/nextjs/server";
import { cookies } from "next/headers";

/**
 * Server-side Supabase client, scoped to the signed-in user via the
 * Clerk session token. Supabase is configured as a Clerk "third-party auth"
 * provider (Project Settings -> Authentication -> Third Party Auth -> Clerk),
 * so the Clerk JWT's `sub` claim maps to `auth.jwt() ->> 'sub'` inside RLS.
 *
 * Use this for anything that should respect Row Level Security
 * (reading a buyer's own orders, cart, wishlist, etc).
 */
export async function createSupabaseServerClient() {
  const cookieStore = await cookies();
  const { getToken } = await auth();
  const token = await getToken({ template: "supabase" });

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: () => {
          // Auth cookies are managed by Clerk, not Supabase, in this setup.
        },
      },
      global: {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      },
    }
  );
}
